//
//  MVVMViewModel.m
//  002-MVVM
//
//  Created by Cooci on 2018/4/1.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "MVVMViewModel.h"

@implementation MVVMViewModel

- (instancetype)init{
    if (self==[super init]) {
        
        [self addObserver:self forKeyPath:@"contentKey" options:(NSKeyValueObservingOptionNew) context:nil];
        
    }
    return self;
}


- (void)loadData{
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [NSThread sleepForTimeInterval:1];
        NSArray *array = @[@"转账",@"信用卡",@"充值中心",@"蚂蚁借呗",@"电影票",@"滴滴出行",@"城市服务",@"蚂蚁森林"];
        dispatch_async(dispatch_get_main_queue(), ^{
            // 外面调用 封装的代码块 能够获取到我们给的数据 (及时性)
            self.successBlock(array);
        });
    });
}

// 精 ---> 难 ----> 窄 ----> 宽 (大牛)
// 架构模式 + RAC + 直播架构 + adpater + 设计模式 + 组件化 + 路由  (项目 : 代码)
// 3-5  8  - 10  -15  20 -  30  内退

#pragma mark -  KVO回调
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    
    NSString *contentKey = change[NSKeyValueChangeNewKey];
    
    NSArray *array = @[@"转账",@"信用卡",@"充值中心",@"蚂蚁借呗",@"电影票",@"滴滴出行",@"城市服务",@"蚂蚁森林"];
    NSMutableArray *mArray = [NSMutableArray arrayWithArray:array];
    
    @synchronized (self) {
        [mArray removeObject:contentKey];
    }
    
    self.successBlock(mArray);

}


- (void)dealloc{
    
    [self removeObserver:self forKeyPath:@"contentKey"];
}

@end
