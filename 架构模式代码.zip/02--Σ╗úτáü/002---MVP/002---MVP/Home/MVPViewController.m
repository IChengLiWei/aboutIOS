//
//  MVPViewController.m
//  MVPDemo
//
//  Created by Cooci on 2018/3/31.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "MVPViewController.h"
#import "LMDataSource.h"
#import "MVPTableViewCell.h"
#import "Model.h"
#import "Present.h"
#import <YYKit.h>

static NSString *const reuserId = @"reuserId";

@interface MVPViewController ()<PresentDelegate>
@property (nonatomic, strong) UITableView       *tableView;
@property (nonatomic, strong) LMDataSource      *dataSource;
@property (nonatomic, strong) Present           *pt;

@end

@implementation MVPViewController

// model <--> UI
// 解耦
// MVP : 面向协议编程
- (void)viewDidLoad {
    [super viewDidLoad];
    // 桥梁
    self.pt = [[Present alloc] init]; //  loadData
    __weak typeof(self) weakSelf = self;
    self.dataSource = [[LMDataSource alloc] initWithIdentifier:reuserId configureBlock:^(MVPTableViewCell *cell, Model *model, NSIndexPath *indexPath) {
        cell.numLabel.text  = model.num;
        cell.nameLabel.text = model.name;
        cell.indexPath      = indexPath;
        cell.delegate       = weakSelf.pt;
    }];
    [self.dataSource addDataArray:self.pt.dataArray];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self.dataSource;
    self.pt.delegate          = self;
}

#pragma mark - PresentDelegate
- (void)reloadUI{
    [self.dataSource addDataArray:self.pt.dataArray];
    [self.tableView reloadData];
}

#pragma mark - lazy

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor whiteColor];
        [_tableView registerClass:[MVPTableViewCell class] forCellReuseIdentifier:reuserId];
    }
    return _tableView;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
