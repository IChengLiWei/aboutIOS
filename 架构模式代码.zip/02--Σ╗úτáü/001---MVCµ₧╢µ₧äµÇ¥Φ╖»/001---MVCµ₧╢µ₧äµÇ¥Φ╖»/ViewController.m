//
//  ViewController.m
//  001---MVC架构思路
//
//  Created by cooci on 2018/10/20.
//  Copyright © 2018 cooci. All rights reserved.
//

#import "ViewController.h"
#import "MVCViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.navigationController pushViewController:[MVCViewController new] animated:YES];
    });

}


@end
