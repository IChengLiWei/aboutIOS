//
//  Present.m
//  003--MVP
//
//  Created by Cooci on 2018/4/1.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "Present.h"

@implementation Present

- (instancetype)init{
    self = [super init];
    if (self) {
        
        [self loadData];
    }
    return self;
}


- (void)loadData{
    
    NSArray *temArray =
    @[
      @{@"name":@"Hank",@"imageUrl":@"http://CC",@"num":@"99"},
      @{@"name":@"Cooci",@"imageUrl":@"http://James",@"num":@"99"},
      @{@"name":@"Kody",@"imageUrl":@"http://Gavin",@"num":@"99"},
      @{@"name":@"小雁子",@"imageUrl":@"http://Cooci",@"num":@"59"},
      @{@"name":@"Lina",@"imageUrl":@"http://Dean ",@"num":@"49"}];
    for (int i = 0; i<temArray.count; i++) {
        Model *m = [Model modelWithDictionary:temArray[i]];
        [self.dataArray addObject:m];
    }
}



#pragma mark - lazy

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray arrayWithCapacity:10];
    }
    return _dataArray;
}

@end
