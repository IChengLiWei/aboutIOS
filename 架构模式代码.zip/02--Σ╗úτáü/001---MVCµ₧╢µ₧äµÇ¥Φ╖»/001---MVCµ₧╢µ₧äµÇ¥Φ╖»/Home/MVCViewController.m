//
//  MVPViewController.m
//  MVPDemo
//
//  Created by Cooci on 2018/3/31.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "MVCViewController.h"
#import "LMDataSource.h"
#import "MVCTableViewCell.h"
#import "Present.h"
#import "Model.h"
#import <YYKit.h>

static NSString *const reuserId = @"reuserId";

@interface MVCViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView       *tableView;
@property (nonatomic, strong) NSMutableArray    *dataArray;
@property (nonatomic, strong) LMDataSource      *dataSource;
@property (nonatomic, strong) Present           *pt;

@end

@implementation MVCViewController

/**
 1: 耦合性强
 2: cell服用  UI <---> model (双向绑定)
 3: VC 好重 : adapter
 */



- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self loadData];
    // RAC --- rxSwift
    self.dataSource = [[LMDataSource alloc] initWithIdentifier:reuserId configureBlock:^(MVCTableViewCell *cell, Model *model, NSIndexPath *indexPath) {
        cell.model = model;
    }];
    
    self.pt = [[Present alloc] init];
    [self.dataSource addDataArray:self.pt.dataArray];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self.dataSource;
//    self.tableView.delegate = self;
    
}

//- (void)loadData{
//    
//    NSArray *temArray =
//    @[
//      @{@"name":@"Hank",@"imageUrl":@"http://CC",@"num":@"99"},
//      @{@"name":@"Cooci",@"imageUrl":@"http://James",@"num":@"99"},
//      @{@"name":@"Kody",@"imageUrl":@"http://Gavin",@"num":@"99"},
//      @{@"name":@"小雁子",@"imageUrl":@"http://Cooci",@"num":@"59"},
//      @{@"name":@"Lina",@"imageUrl":@"http://Dean ",@"num":@"49"}];
//    for (int i = 0; i<temArray.count; i++) {
//        Model *m = [Model modelWithDictionary:temArray[i]];
//        [self.dataArray addObject:m];
//    }
//}
//
//#pragma mark - tableViewDataSource
//
//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return self.dataArray.count;
//}
//
//
//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    MVCTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuserId forIndexPath:indexPath];
//    // 不合理
//    cell.model = self.dataArray[indexPath.row];
//    return cell;
//}


//#pragma mark - tableViewDelegate
//
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//}


#pragma mark - lazy

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray arrayWithCapacity:10];
    }
    return _dataArray;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor whiteColor];
        [_tableView registerClass:[MVCTableViewCell class] forCellReuseIdentifier:reuserId];
    }
    return _tableView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
